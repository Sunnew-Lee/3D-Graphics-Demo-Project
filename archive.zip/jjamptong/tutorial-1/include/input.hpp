#pragma once

/*  Public functions, so far only allow these interactions */
void MoveUp();
void MoveDown();
void MoveLeft();
void MoveRight();
void MoveCloser();
void MoveFarther();

